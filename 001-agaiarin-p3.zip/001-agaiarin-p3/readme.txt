Alessandro Gaiarin
agaiarin
G00800359
Lecture: 001
